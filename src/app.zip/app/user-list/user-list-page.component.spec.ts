import { async, ComponentFixture, TestBed } from '@angular/core/testing';



describe('FirstPageComponent', () => {
  
  

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: []
    })
    .compileComponents();
  }));

  beforeEach(() => {
  });

  it('should create', () => {
    // expect(component).toBeTruthy();
  });
});
